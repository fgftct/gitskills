window.addEventListener('load', function() {
    var left = document.querySelector('.left');
    var right = document.querySelector('.right');
    var slider = document.querySelector('.slider');
    var list = document.querySelector('.list');
    var ol = document.querySelector('ol');
    var max = slider.offsetWidth;
    slider.addEventListener('mouseenter', function() {
        left.style.display = 'block';
        right.style.display = 'block';

    })
    slider.addEventListener('mouseleave', function() {
        left.style.display = 'none';
        right.style.display = 'none';

    })
    for (var i = 0; i < list.children.length; i++) {
        var li = document.createElement('li');
        li.setAttribute('index', i);
        ol.appendChild(li);
        li.addEventListener('click', function() {
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            this.className = 'current';
            var index = this.getAttribute('index');
            animate(list, -index * max);
        })
    }
    //设置第一个按钮为白色
    ol.children[0].className = 'current';
    var clone = list.children[0].cloneNode(true);
    list.appendChild(clone);
    var num = 0;
    right.addEventListener('click', function() {
        if (num == list.children.length - 1) {
            list.style.left = 0 + 'px';
            num = 0;
        }
        num++;
        animate(list, -num * max);
    })
})