//封一个函数
function anumate(obj, target, callback) {
    // 先清除以前的定时器，只保留当前的一个定时器执行
    //如果这步省略的话每次调用函数时就会不断地增加位移
    clearInterval(obj.timer);
    //定时器
    var timer = setInterval(function() {
        var step = (target - obj.offsetLeft) / 10;
        step = step > 0 ? Math.ceil(step) : Math.floor(step);
        //如果当前位置大于或小于目标位置时
        if (obj.offsetLeft >= target) {
            setInterval(timer);
            callback && callback();
        }
        obj.style.left = obj.offsetLeft + step + 'px';
    }, 15)
}